#include<bits/stdc++.h>
using namespace std;

int main(){
	bool f = false;
	vector < pair < char,string > > gram;
    int n = 3;      // number of productions
    string s = "";
    for(int i=0;i<n;i++){
        cin>>s;
        pair < char , string > p;
        p = make_pair(s[0],s.substr(3));
        gram.push_back(p);
    }
    map < pair < int , char > , string > mp;
    mp[make_pair(0,'a')] = "S3";
    mp[make_pair(0,'b')] = "S4";
    mp[make_pair(0,'A')] = "2";
    mp[make_pair(0,'S')] = "1";
    
    mp[make_pair(1,'$')] = "ACC";
    
    mp[make_pair(2,'a')] = "S3";
    mp[make_pair(2,'b')] = "S4";
    mp[make_pair(2,'A')] = "5";
    
    mp[make_pair(3,'a')] = "S3";
    mp[make_pair(3,'b')] = "S4";
    mp[make_pair(3,'A')] = "6";
    
    mp[make_pair(4,'a')] = "R3";
    mp[make_pair(4,'b')] = "R3";
    mp[make_pair(4,'$')] = "R3";
    
    mp[make_pair(5,'a')] = "R1";
    mp[make_pair(5,'b')] = "R1";
    mp[make_pair(5,'$')] = "R1";
    
    mp[make_pair(6,'a')] = "R2";
    mp[make_pair(6,'b')] = "R2";
    mp[make_pair(6,'$')] = "R2";
    
    stack <char> st;
    st.push('0');
    string ip;
    cout<<"\nEnter the input string : ";
    cin>>ip;
    
    ip+='$';
    int sz = ip.length();
    int i = 0;
    while(i<sz){
    	if(mp.find(make_pair(st.top()-'0',ip[i]))==mp.end()){
    		cout<<"1\n";
    		//cout<<"\nInput string REJECTED !!!\n";
    		//cout<<"1a";
    		break;
		}
		else{
			string temp = mp[make_pair(st.top()-'0',ip[i])];
			if(temp=="ACC"){
				cout<<"2\n";
				cout<<"\nInput string ACCEPTED !!!\n";
				f = true;
    			break;
			}
			else
			if(temp[0]=='S'){
				cout<<"3\n";
				st.push(ip[i]);
				st.push(temp[1]);
				i++;
			}
			else
			if(temp[0]=='R'){
				cout<<"4\n";
				pair < char,string > p = gram[(temp[1]-'0')-1];
				int x = p.second.size();
				x+=x;
				while(x--){
					st.pop();
				}
				x = st.top()-'0';
				if( mp.find(make_pair(x,p.first) ) == mp.end()){
					//cout<<"1b";
					break;
				}
				else{
					string temp1 = mp[make_pair(x,p.first)];
					st.push(p.first+'0');
					st.push(temp1[0]);
				}
			}
		}
	}
	if(f==false){
		cout<<"\nInput string REJECTED !!!\n";
	}
    
}
