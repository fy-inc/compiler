


#include<bits/stdc++.h>
using namespace std;

struct item{

        pair < char,string  >  prod;
        int dotpos;

};





void closure( vector < item  > &I,vector < pair < char,string > > gram ){


        for(int i=0;i<I.size();i++){

        char ch;
        if(I[i].dotpos == I[i].prod.second.size())
                continue;
        else
                ch = I[i].prod.second[I[i].dotpos];
        for(int j=0;j<gram.size();j++){

                if(gram[j].first==ch){

                        item temp;
                        temp.prod  = gram[j];
                        temp.dotpos = 0;
                        I.push_back(temp);

                }

        }

        }

}

void disp(vector < item > I ){

        for(int i=0;i<I.size();i++){
                cout<<I[i].prod.first<<"->"<<I[i].prod.second<<" DOTPOS = "<<I[i].dotpos;
                cout<<"\n";
        }

}

bool iscom(item I){

        if(I.dotpos==I.prod.second.size())
                return true;
        else
                return false;

}

bool isSame(item i1,item i2){
	return i1.prod.first==i2.prod.first&&i1.prod.second==i2.prod.second&&i1.dotpos==i2.dotpos;
}

bool alreadyPresent(vector < vector < item > > cnn , vector < item > temp){
	for(int i=0;i<cnn.size();i++){
		bool var = true;
		vector< item > p = cnn[i];
		int j = 0,k = 0;
		while(j<p.size()&&k<temp.size()){
			if(!isSame(cnn[i][j++],temp[k++]))
				var = false;
		}
		if(var==true)
			return true;
	}
	return false;
}

int main(){
        vector < pair < char,string > > gram;
        int n = 3;      // number of productions
        string s = "";
        for(int i=0;i<n;i++){
                cin>>s;
                pair < char , string > p;
                p = make_pair(s[0],s.substr(3));
                gram.push_back(p);
        }
        vector < item > I1;
        item temp;
        temp.dotpos = 0;
        temp.prod = make_pair( 'X',"S"  );
        I1.push_back(temp);
        closure(I1,gram);

        //disp(I1);
        //cout<<"\n\n\n";

        vector < vector < item > > cnn;
        cnn.push_back(I1);
        for(int i = 0;i<cnn.size();i++){

                for(int j=0;j<cnn[i].size();j++){

                        if(!iscom(cnn[i][j])){

                                vector < item > temp;
                                item it = cnn[i][j];
                                it.dotpos++;
                                temp.push_back(it);
                                closure(temp,gram);
                                if(!alreadyPresent(cnn,temp))
                                	cnn.push_back(temp);

                        }

                }

        }

        for(int i=0;i<cnn.size();i++){

                disp(cnn[i]);
                cout<<"\n-----------------------\n";

        }


        return 0;
}
