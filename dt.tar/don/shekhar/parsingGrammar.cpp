#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<iostream>
using namespace std;

int n;
string grammar[10];

int checkreduce(char stack[],int i)
{
	int ans = -1;
	int j;
	int ls = strlen(stack);
	int lg = grammar[i].size();
	int c = 0;
	if(lg<=ls)
	for(j=0;j<lg;j++)
		if(grammar[i][j]==stack[ls-lg+j])
			c++;
	if(c==lg)
		ans = i;
	return ans;
}

int r(char stack[],char input[],char var[])
{
	int ls = strlen(stack);
	int li = strlen(input);
	int r1 = 0,r2 = 0;
	int i;
	int ans;
	if(strlen(input)==0)
	{	
		if(stack[0]==var[0]&&strlen(stack)==1)
			return 1;
	}
	for(int j=0;j<n;j++)
	{
		ans = checkreduce(stack,j);
		if(ans!=-1)
		{
			char newstack[30] = "\0";
			char newinput[30] = "\0";
			strcpy(newinput,input);
			int lg = grammar[ans].size();
			for(i=0;i<ls-lg;i++)
				newstack[i] = stack[i];
			newstack[i] = var[ans];
			r1 = r(newstack,newinput,var);
			if(r1==1)
				{
					cout<<var[ans]<<" "<<grammar[ans]<<endl;
					return 1;
				}		
		}
	}
	
	if(strlen(input)!=0)
	{
		char newstack[30]= "\0";
		char newinput[30]= "\0";
		strcpy(newstack,stack);
		newstack[ls] = input[0];
		for(i=0;i<li;i++)
			newinput[i] = input[i+1];
		r2 = r(newstack,newinput,var);
	}
	return r2;

}

int main()
{
	char stack[30]="\0";
	char input[30];
	printf("enter the number of grammar rules\n");
	scanf("%d",&n);
	char var[n];
	int i=0;
	//printf("%d",n);
	for(i=0;i<n;i++)
		{
			cin>>var[i];
			cin>>grammar[i];
		}
	printf("enter your input\n");
	scanf("%s",input);
	printf("%d",r(stack,input,var));
	return 0;
}
/*
3
E 2E2
E 3E3
E 4
23432
*/